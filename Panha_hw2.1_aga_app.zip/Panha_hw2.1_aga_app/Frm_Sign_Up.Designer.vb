﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Sign_Up
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2CustomGradientPanel1 = New Guna.UI2.WinForms.Guna2CustomGradientPanel()
        Me.Gbt_Signup = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.Guna2HtmlLabel3 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Gbt_Close = New Guna.UI2.WinForms.Guna2Button()
        Me.Check_Pw = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.Gbt_Signin = New Guna.UI2.WinForms.Guna2GradientButton()
        Me.Guna2PictureBox5 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.txt_Pw = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2PictureBox4 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.txt_Email = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2PictureBox3 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox2 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2PictureBox1 = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Guna2HtmlLabel5 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2HtmlLabel4 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2CustomGradientPanel1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        CType(Me.Guna2PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Guna2CustomGradientPanel1
        '
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Gbt_Signup)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel3)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2CustomGradientPanel1.Controls.Add(Me.Panel1)
        Me.Guna2CustomGradientPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Guna2CustomGradientPanel1.FillColor = System.Drawing.Color.DodgerBlue
        Me.Guna2CustomGradientPanel1.FillColor2 = System.Drawing.Color.Cyan
        Me.Guna2CustomGradientPanel1.Location = New System.Drawing.Point(0, 0)
        Me.Guna2CustomGradientPanel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Guna2CustomGradientPanel1.Name = "Guna2CustomGradientPanel1"
        Me.Guna2CustomGradientPanel1.Size = New System.Drawing.Size(750, 609)
        Me.Guna2CustomGradientPanel1.TabIndex = 0
        '
        'Gbt_Signup
        '
        Me.Gbt_Signup.Animated = True
        Me.Gbt_Signup.AutoRoundedCorners = True
        Me.Gbt_Signup.BackColor = System.Drawing.Color.Transparent
        Me.Gbt_Signup.BorderColor = System.Drawing.Color.White
        Me.Gbt_Signup.BorderRadius = 23
        Me.Gbt_Signup.BorderThickness = 2
        Me.Gbt_Signup.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Gbt_Signup.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Gbt_Signup.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Gbt_Signup.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Gbt_Signup.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Gbt_Signup.Font = New System.Drawing.Font("Segoe UI Semibold", 13.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Gbt_Signup.ForeColor = System.Drawing.Color.White
        Me.Gbt_Signup.Location = New System.Drawing.Point(94, 314)
        Me.Gbt_Signup.Margin = New System.Windows.Forms.Padding(2)
        Me.Gbt_Signup.Name = "Gbt_Signup"
        Me.Gbt_Signup.Size = New System.Drawing.Size(135, 49)
        Me.Gbt_Signup.TabIndex = 4
        Me.Gbt_Signup.Text = "SignUp"
        Me.Gbt_Signup.UseTransparentBackground = True
        '
        'Guna2HtmlLabel3
        '
        Me.Guna2HtmlLabel3.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel3.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel3.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel3.Location = New System.Drawing.Point(55, 220)
        Me.Guna2HtmlLabel3.Margin = New System.Windows.Forms.Padding(2)
        Me.Guna2HtmlLabel3.Name = "Guna2HtmlLabel3"
        Me.Guna2HtmlLabel3.Size = New System.Drawing.Size(258, 20)
        Me.Guna2HtmlLabel3.TabIndex = 3
        Me.Guna2HtmlLabel3.Text = "SignUp Now To Connect With Us!"
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(131, 157)
        Me.Guna2HtmlLabel2.Margin = New System.Windows.Forms.Padding(2)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(98, 33)
        Me.Guna2HtmlLabel2.TabIndex = 2
        Me.Guna2HtmlLabel2.Text = "SingUp"
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(18, 25)
        Me.Guna2HtmlLabel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(153, 39)
        Me.Guna2HtmlLabel1.TabIndex = 1
        Me.Guna2HtmlLabel1.Text = "Welcome!"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.White
        Me.Panel1.Controls.Add(Me.Gbt_Close)
        Me.Panel1.Controls.Add(Me.Check_Pw)
        Me.Panel1.Controls.Add(Me.Gbt_Signin)
        Me.Panel1.Controls.Add(Me.Guna2PictureBox5)
        Me.Panel1.Controls.Add(Me.txt_Pw)
        Me.Panel1.Controls.Add(Me.Guna2PictureBox4)
        Me.Panel1.Controls.Add(Me.txt_Email)
        Me.Panel1.Controls.Add(Me.Guna2PictureBox3)
        Me.Panel1.Controls.Add(Me.Guna2PictureBox2)
        Me.Panel1.Controls.Add(Me.Guna2PictureBox1)
        Me.Panel1.Controls.Add(Me.Guna2HtmlLabel5)
        Me.Panel1.Controls.Add(Me.Guna2HtmlLabel4)
        Me.Panel1.Location = New System.Drawing.Point(358, 0)
        Me.Panel1.Margin = New System.Windows.Forms.Padding(2)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(403, 609)
        Me.Panel1.TabIndex = 0
        '
        'Gbt_Close
        '
        Me.Gbt_Close.BackgroundImage = Global.Panha_hw2._1_aga_app.My.Resources.Resources._11244080_x_twitter_elon_musk_twitter_new_logo_icon
        Me.Gbt_Close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Gbt_Close.BorderColor = System.Drawing.Color.Transparent
        Me.Gbt_Close.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Gbt_Close.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Gbt_Close.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Gbt_Close.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Gbt_Close.FillColor = System.Drawing.Color.Transparent
        Me.Gbt_Close.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Gbt_Close.ForeColor = System.Drawing.Color.White
        Me.Gbt_Close.Location = New System.Drawing.Point(362, 3)
        Me.Gbt_Close.Name = "Gbt_Close"
        Me.Gbt_Close.Size = New System.Drawing.Size(27, 23)
        Me.Gbt_Close.TabIndex = 15
        '
        'Check_Pw
        '
        Me.Check_Pw.AutoSize = True
        Me.Check_Pw.BackColor = System.Drawing.SystemColors.Menu
        Me.Check_Pw.BackgroundImage = Global.Panha_hw2._1_aga_app.My.Resources.Resources.images
        Me.Check_Pw.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.Check_Pw.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Check_Pw.CheckedState.BorderRadius = 0
        Me.Check_Pw.CheckedState.BorderThickness = 0
        Me.Check_Pw.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Check_Pw.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!)
        Me.Check_Pw.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.Check_Pw.Location = New System.Drawing.Point(316, 349)
        Me.Check_Pw.Name = "Check_Pw"
        Me.Check_Pw.Size = New System.Drawing.Size(15, 14)
        Me.Check_Pw.TabIndex = 14
        Me.Check_Pw.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Check_Pw.UncheckedState.BorderRadius = 0
        Me.Check_Pw.UncheckedState.BorderThickness = 0
        Me.Check_Pw.UncheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.Check_Pw.UseVisualStyleBackColor = False
        '
        'Gbt_Signin
        '
        Me.Gbt_Signin.Animated = True
        Me.Gbt_Signin.AutoRoundedCorners = True
        Me.Gbt_Signin.BackColor = System.Drawing.Color.Transparent
        Me.Gbt_Signin.BorderColor = System.Drawing.Color.White
        Me.Gbt_Signin.BorderRadius = 23
        Me.Gbt_Signin.BorderThickness = 2
        Me.Gbt_Signin.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Gbt_Signin.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Gbt_Signin.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Gbt_Signin.DisabledState.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Gbt_Signin.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Gbt_Signin.Font = New System.Drawing.Font("Segoe UI Semibold", 13.8!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Gbt_Signin.ForeColor = System.Drawing.Color.White
        Me.Gbt_Signin.Location = New System.Drawing.Point(113, 418)
        Me.Gbt_Signin.Margin = New System.Windows.Forms.Padding(2)
        Me.Gbt_Signin.Name = "Gbt_Signin"
        Me.Gbt_Signin.Size = New System.Drawing.Size(175, 49)
        Me.Gbt_Signin.TabIndex = 5
        Me.Gbt_Signin.Text = "SignUp"
        Me.Gbt_Signin.UseTransparentBackground = True
        '
        'Guna2PictureBox5
        '
        Me.Guna2PictureBox5.Image = Global.Panha_hw2._1_aga_app.My.Resources.Resources._2849796_lock_security_multimedia_close_protection_icon
        Me.Guna2PictureBox5.ImageRotate = 0!
        Me.Guna2PictureBox5.Location = New System.Drawing.Point(62, 342)
        Me.Guna2PictureBox5.Name = "Guna2PictureBox5"
        Me.Guna2PictureBox5.Size = New System.Drawing.Size(26, 21)
        Me.Guna2PictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox5.TabIndex = 13
        Me.Guna2PictureBox5.TabStop = False
        '
        'txt_Pw
        '
        Me.txt_Pw.BorderRadius = 10
        Me.txt_Pw.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Pw.DefaultText = ""
        Me.txt_Pw.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt_Pw.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt_Pw.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Pw.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Pw.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Pw.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_Pw.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Pw.Location = New System.Drawing.Point(51, 334)
        Me.txt_Pw.Name = "txt_Pw"
        Me.txt_Pw.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt_Pw.PlaceholderText = ""
        Me.txt_Pw.SelectedText = ""
        Me.txt_Pw.Size = New System.Drawing.Size(290, 44)
        Me.txt_Pw.TabIndex = 12
        Me.txt_Pw.TextOffset = New System.Drawing.Point(30, 0)
        '
        'Guna2PictureBox4
        '
        Me.Guna2PictureBox4.Image = Global.Panha_hw2._1_aga_app.My.Resources.Resources._134146_mail_email_icon
        Me.Guna2PictureBox4.ImageRotate = 0!
        Me.Guna2PictureBox4.Location = New System.Drawing.Point(62, 285)
        Me.Guna2PictureBox4.Name = "Guna2PictureBox4"
        Me.Guna2PictureBox4.Size = New System.Drawing.Size(26, 21)
        Me.Guna2PictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox4.TabIndex = 11
        Me.Guna2PictureBox4.TabStop = False
        '
        'txt_Email
        '
        Me.txt_Email.BorderRadius = 10
        Me.txt_Email.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.txt_Email.DefaultText = ""
        Me.txt_Email.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.txt_Email.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.txt_Email.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Email.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.txt_Email.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Email.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.txt_Email.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.txt_Email.Location = New System.Drawing.Point(51, 275)
        Me.txt_Email.Name = "txt_Email"
        Me.txt_Email.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.txt_Email.PlaceholderText = ""
        Me.txt_Email.SelectedText = ""
        Me.txt_Email.Size = New System.Drawing.Size(290, 44)
        Me.txt_Email.TabIndex = 10
        Me.txt_Email.TextOffset = New System.Drawing.Point(30, 0)
        '
        'Guna2PictureBox3
        '
        Me.Guna2PictureBox3.Image = Global.Panha_hw2._1_aga_app.My.Resources.Resources._3225194_app_facebook_logo_media_popular_icon
        Me.Guna2PictureBox3.ImageRotate = 0!
        Me.Guna2PictureBox3.Location = New System.Drawing.Point(178, 135)
        Me.Guna2PictureBox3.Name = "Guna2PictureBox3"
        Me.Guna2PictureBox3.Size = New System.Drawing.Size(47, 37)
        Me.Guna2PictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox3.TabIndex = 9
        Me.Guna2PictureBox3.TabStop = False
        '
        'Guna2PictureBox2
        '
        Me.Guna2PictureBox2.Image = Global.Panha_hw2._1_aga_app.My.Resources.Resources._734383_in_linked_media_online_social_icon
        Me.Guna2PictureBox2.ImageRotate = 0!
        Me.Guna2PictureBox2.Location = New System.Drawing.Point(241, 135)
        Me.Guna2PictureBox2.Name = "Guna2PictureBox2"
        Me.Guna2PictureBox2.Size = New System.Drawing.Size(47, 37)
        Me.Guna2PictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox2.TabIndex = 8
        Me.Guna2PictureBox2.TabStop = False
        '
        'Guna2PictureBox1
        '
        Me.Guna2PictureBox1.Image = Global.Panha_hw2._1_aga_app.My.Resources.Resources._1298745_google_brand_branding_logo_network_icon
        Me.Guna2PictureBox1.ImageRotate = 0!
        Me.Guna2PictureBox1.Location = New System.Drawing.Point(113, 135)
        Me.Guna2PictureBox1.Name = "Guna2PictureBox1"
        Me.Guna2PictureBox1.Size = New System.Drawing.Size(47, 37)
        Me.Guna2PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom
        Me.Guna2PictureBox1.TabIndex = 7
        Me.Guna2PictureBox1.TabStop = False
        '
        'Guna2HtmlLabel5
        '
        Me.Guna2HtmlLabel5.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel5.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel5.ForeColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(56, Byte), Integer))
        Me.Guna2HtmlLabel5.Location = New System.Drawing.Point(113, 220)
        Me.Guna2HtmlLabel5.Margin = New System.Windows.Forms.Padding(2)
        Me.Guna2HtmlLabel5.Name = "Guna2HtmlLabel5"
        Me.Guna2HtmlLabel5.Size = New System.Drawing.Size(175, 20)
        Me.Guna2HtmlLabel5.TabIndex = 6
        Me.Guna2HtmlLabel5.Text = "or use email to sign in:"
        '
        'Guna2HtmlLabel4
        '
        Me.Guna2HtmlLabel4.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel4.Font = New System.Drawing.Font("Microsoft Sans Serif", 20.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel4.ForeColor = System.Drawing.Color.FromArgb(CType(CType(22, Byte), Integer), CType(CType(41, Byte), Integer), CType(CType(56, Byte), Integer))
        Me.Guna2HtmlLabel4.Location = New System.Drawing.Point(153, 75)
        Me.Guna2HtmlLabel4.Margin = New System.Windows.Forms.Padding(2)
        Me.Guna2HtmlLabel4.Name = "Guna2HtmlLabel4"
        Me.Guna2HtmlLabel4.Size = New System.Drawing.Size(98, 33)
        Me.Guna2HtmlLabel4.TabIndex = 5
        Me.Guna2HtmlLabel4.Text = "SingUp"
        '
        'Sign_Up
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(750, 609)
        Me.Controls.Add(Me.Guna2CustomGradientPanel1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "Sign_Up"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Guna2CustomGradientPanel1.ResumeLayout(False)
        Me.Guna2CustomGradientPanel1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        CType(Me.Guna2PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Guna2PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Guna2CustomGradientPanel1 As Guna.UI2.WinForms.Guna2CustomGradientPanel
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Gbt_Signup As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Guna2HtmlLabel3 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel4 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2HtmlLabel5 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2PictureBox1 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2PictureBox3 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2PictureBox2 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents Guna2PictureBox4 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents txt_Email As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2PictureBox5 As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents txt_Pw As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Gbt_Signin As Guna.UI2.WinForms.Guna2GradientButton
    Friend WithEvents Check_Pw As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents Gbt_Close As Guna.UI2.WinForms.Guna2Button
End Class
