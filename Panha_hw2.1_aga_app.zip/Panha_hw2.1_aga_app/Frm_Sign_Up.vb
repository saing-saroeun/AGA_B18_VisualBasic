﻿Public Class Sign_Up


    Private Sub Gbt_Close_Click(sender As Object, e As EventArgs) Handles Gbt_Close.Click
        Me.Close()
        Me.Hide()
    End Sub


    Private Sub txt_Email_GotFocus(sender As Object, e As EventArgs) Handles txt_Email.GotFocus
        If txt_Email.Text = "Email" Then
            txt_Email.Text = ""
            txt_Email.ForeColor = Color.DimGray
        End If
    End Sub

    Private Sub txt_Email_LostFocus(sender As Object, e As EventArgs) Handles txt_Email.LostFocus
        If txt_Email.Text = "" Then
            txt_Email.Text = "Email"
            txt_Email.ForeColor = Color.DarkGray

        End If
    End Sub

    Private Sub txt_Pw_GotFocus(sender As Object, e As EventArgs) Handles txt_Pw.GotFocus
        If txt_Pw.Text = "Password" Then
            txt_Pw.Text = ""
            txt_Pw.PasswordChar = "•"
            txt_Pw.ForeColor = Color.DimGray

        End If
    End Sub

    Private Sub txt_Pw_LostFocus(sender As Object, e As EventArgs) Handles txt_Pw.LostFocus
        If txt_Pw.Text = "" Then
            txt_Pw.Text = "Password"
            'txt_Pw.PasswordChar = "•"
            txt_Pw.ForeColor = Color.DarkGray
        End If
    End Sub

    Private Sub Sign_Up_Load(sender As Object, e As EventArgs) Handles Me.Load
        txt_Email.Text = "Email"
        txt_Email.ForeColor = Color.DimGray

        txt_Pw.Text = "Password"
        txt_Pw.ForeColor = Color.DimGray
    End Sub

    Private Sub Check_Pw_CheckedChanged(sender As Object, e As EventArgs) Handles Check_Pw.CheckedChanged
        If Check_Pw.Checked = False Then
            txt_Pw.PasswordChar = "•"

        Else
            txt_Pw.PasswordChar = ""
        End If
    End Sub
End Class
